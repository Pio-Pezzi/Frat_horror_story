from enemy import Fish
from projectile import Projectile
import pygame as py
import math
from vector import Vector
class Fighter:
    """Squares placed by player to combat enemies."""