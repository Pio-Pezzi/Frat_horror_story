import pygame as py
from vector import Vector
class Projectile:
    """Moves on initialized vector, handled by fighter and gm classes."""